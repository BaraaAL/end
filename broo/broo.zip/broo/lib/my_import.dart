//export 'package:book_an_event/couch.dart';
//export 'package:book_an_event/model/crud.dart';
export  'package:broo/couch.dart';
export 'package:flutter/cupertino.dart';

export 'package:get/get_core/src/get_main.dart';
//import 'package:book_an_event/couch.dart';
// import 'package:book_an_event/model/crud.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:http/http.dart'as http;
// import 'package:book_an_event/viwe/homepage.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';