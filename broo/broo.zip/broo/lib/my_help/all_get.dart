


import 'package:broo/helper/api.dart';
import 'package:broo/model/foodDetailes_model.dart';
class GetAll{

  Future<foodDetailes_modelResponse> getFoodOne()async{


    var data= Api().get(url: 'http://192.168.43.230:8000/api/allFoods',);
    foodDetailes_modelResponse foodCategoryList =foodDetailes_modelResponse.fromJson(data as Map<String, dynamic>);
    return foodCategoryList;


  }
}