import 'dart:io';


import 'package:broo/abd.dart';
import 'package:broo/model/foodDetailes_model.dart';
import 'package:broo/my_help/all_get.dart';
//import 'package:book_an_event/services/get_all_product_service.dart';
import 'package:broo/abd.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:broo/model/foodDetailes_model.dart';

class FoodDetails extends StatefulWidget {
  @override
  _FoodDetailsState createState() => _FoodDetailsState();
}

class _FoodDetailsState extends State<FoodDetails> {
  //String ? name;
  //String  ?description ;
 // double ? price ;


//  @override
  /* void initState() {
    super.initState();
    fetchData();

  //  _getFoodDetails();
  }

  Future<void> fetchData() async {
    try {
      final response = await http.get(Uri.parse('http://localhost:8000/api/allFoods'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          // Process the data
          final foodDetails = data['data'];
          // ...
        } else {
          // Handle the case where data['data'] is null
          print('Data is null');
        }
      } else {
        // Handle the error
        print('Error: ${response.statusCode}');
      }
    } catch (e) {
      // Handle any other exceptions
      print('Error: $e');
    }
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food Details'),
        backgroundColor: Color(0xffb47b84),
      ),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: FutureBuilder<foodDetailes_modelResponse>(

            // child: FutureBuilder<List<ProductModel>>(
            future: GetAll().getFoodOne( ),
            //future: AllProductsService().getAllProducts(),
            builder: (context,snapshot){

              if(snapshot.hasData){
                return ListView(
                  children: [
                    SizedBox(height: 20,),
                    Container(
                      color: Colors.grey,
                      padding: EdgeInsets.all(16),
                      child: Text(snapshot.data!.food[1].name.toString()
                        // '$name'
                      ),
                    ),
                    SizedBox(height: 80),
                    Card(
                      elevation: 4,
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Additional Details',
                              //'Additional Details',
                              style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(snapshot.data!.food[1].description.toString()),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Center(
                      child: Text(snapshot.data!.food[1].price.toString()

                      ),
                    ),
                    SizedBox(height: 300),
                    ElevatedButton(
                      onPressed: () {
                        // Add your "Make Server" functionality here
                        print('Make Server button pressed');
                      },
                      child: Text('Make Server'),
                    ),
                  ],
                );}
              if(snapshot.hasError){
                return
                  Column(
                    children: [
                      Container(child:Text('Erorr').center(),),
                      CircularProgressIndicator(color: Colors.red,).center(),
                    ],
                  );


              }
              else{//CircularProgressIndicator
                return  Column(
                  children: [
                    Container(child:Text('Loging').center(),),
                    CircularProgressIndicator(color: Colors.red,).center(),
                  ],
                );
              }
            },
          )
      ),
    );
  }
}