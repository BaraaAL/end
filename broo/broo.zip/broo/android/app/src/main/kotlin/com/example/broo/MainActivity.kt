package com.example.broo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
